import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import Header from '../components/Header';
import { checklistAPI } from '../utils/api';

export default function Checklist() {
  const { locationId } = useParams();
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState(null);
  const [formData, setFormData] = useState({});
  const [photos, setPhotos] = useState([]);
  const [notes, setNotes] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  // Load checklist data
  useEffect(() => {
    loadChecklist();
  }, [locationId]);

  const loadChecklist = async () => {
    try {
      const response = await checklistAPI.getChecklist(locationId);
      setData(response.data);

      // Initialize form data (radio buttons start with null)
      const initialFormData = {};
      response.data.checklist.config.fields?.forEach(field => {
        initialFormData[field.id] = null;
      });
      setFormData(initialFormData);
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to load checklist');
    } finally {
      setLoading(false);
    }
  };

  const handleRadioChange = (fieldId, value) => {
    setFormData(prev => ({
      ...prev,
      [fieldId]: value
    }));
  };

  const handlePhotoUpload = (e) => {
    const files = Array.from(e.target.files);
    const newPhotos = files.map(file => ({
      file,
      preview: URL.createObjectURL(file),
      id: Math.random().toString(36)
    }));
    setPhotos(prev => [...prev, ...newPhotos]);
  };

  const removePhoto = (id) => {
    setPhotos(prev => prev.filter(p => p.id !== id));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    // Validation (all fields must have a value: complete, incomplete, or na)
    const allAnswered = Object.values(formData).every(v => v !== null);
    if (!allAnswered) {
      setError('Please answer all checklist items (Complete, Incomplete, or N/A)');
      return;
    }

    if (photos.length < 3) {
      setError('Please upload at least 3 photos');
      return;
    }

    setSubmitting(true);

    try {
      const submitData = new FormData();
      submitData.append('serviceId', data.service.id);
      submitData.append('checklistData', JSON.stringify(formData));
      submitData.append('notes', notes);
      submitData.append('submittedBy', data.subcontractor || 'Subcontractor');

      photos.forEach(photo => {
        submitData.append('photos', photo.file);
      });

      await checklistAPI.submitChecklist(locationId, submitData);
      setSubmitted(true);
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to submit checklist');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="loading-overlay">
        <div className="loading-spinner" />
      </div>
    );
  }

  if (error && !data) {
    return (
      <div style={{ minHeight: '100vh', background: 'var(--color-bg-primary)' }}>
        <Header />
        <div className="container container-narrow" style={{ paddingTop: 'var(--space-2xl)' }}>
          <div className="alert alert-error">{error}</div>
        </div>
      </div>
    );
  }

  if (submitted) {
    return (
      <div style={{ minHeight: '100vh', background: 'var(--color-bg-primary)' }}>
        <Header />
        <div className="container container-narrow" style={{ paddingTop: 'var(--space-2xl)' }}>
          <div className="card text-center">
            <div style={{ fontSize: '4rem', marginBottom: 'var(--space-lg)' }}>✓</div>
            <h1 style={{ color: 'var(--color-success)' }}>Checklist Submitted!</h1>
            <p style={{ fontSize: '1.125rem', color: 'var(--color-text-secondary)' }}>
              Thank you for completing the service checklist. Your submission has been recorded.
            </p>
            <div style={{ marginTop: 'var(--space-xl)' }}>
              <button
                onClick={() => window.location.reload()}
                className="btn btn-secondary"
              >
                Submit Another
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Check if IVR is near expiration or expired
  const ivrExpirationDate = data.ivr ? new Date(data.ivr.expirationDate) : null;
  const today = new Date();
  const daysUntilExpiration = ivrExpirationDate
    ? Math.ceil((ivrExpirationDate - today) / (1000 * 60 * 60 * 24))
    : null;
  const isExpired = daysUntilExpiration !== null && daysUntilExpiration < 0;
  const isNearExpiration = daysUntilExpiration !== null && daysUntilExpiration <= 7 && daysUntilExpiration >= 0;

  return (
    <div style={{ minHeight: '100vh', background: 'var(--color-bg-primary)', paddingBottom: 'var(--space-2xl)' }}>
      <Header />

      <div className="container container-narrow" style={{ paddingTop: 'var(--space-xl)' }}>
        {/* Location Info Card */}
        <div className="card" style={{ marginBottom: 'var(--space-xl)', background: 'var(--color-bg-elevated)' }}>
          <div style={{ marginBottom: 'var(--space-lg)' }}>
            <h1 style={{ fontSize: '1.75rem', marginBottom: 'var(--space-sm)' }}>
              {data.location.name}
            </h1>
            <p className="text-secondary" style={{ fontSize: '1rem' }}>
              {data.location.address}, {data.location.city}, {data.location.state} {data.location.zip}
            </p>
          </div>

          {/* Read-only Fields */}
          <div className="grid grid-2" style={{ gap: 'var(--space-md)' }}>
            <div>
              <label className="form-label">Internal WO Number</label>
              <div className="form-input mono" style={{ background: 'var(--color-bg-tertiary)' }}>
                {data.location.internalWo}
              </div>
            </div>
            <div>
              <label className="form-label">ServiceChannel IVR</label>
              <div className="form-input mono" style={{ background: 'var(--color-bg-tertiary)' }}>
                {data.ivr?.ticketNumber || 'N/A'}
              </div>
            </div>
          </div>

          {data.ivr && (
            <div style={{ marginTop: 'var(--space-md)' }}>
              <label className="form-label">IVR Period</label>
              <div className="form-input mono" style={{ background: 'var(--color-bg-tertiary)' }}>
                {data.ivr.periodLabel} (Expires: {new Date(data.ivr.expirationDate).toLocaleDateString()})
              </div>
            </div>
          )}
        </div>

        {/* IVR Expiration Warning */}
        {isExpired && (
          <div className="alert alert-error" style={{ marginBottom: 'var(--space-lg)' }}>
            <strong>⚠️ IVR Expired</strong><br />
            This IVR expired on {ivrExpirationDate.toLocaleDateString()}. A new IVR may be available soon. Please check back later or contact your account manager.
          </div>
        )}

        {isNearExpiration && (
          <div className="alert alert-warning" style={{ marginBottom: 'var(--space-lg)' }}>
            <strong>⚠️ IVR Expiring Soon</strong><br />
            This IVR expires in {daysUntilExpiration} day{daysUntilExpiration !== 1 ? 's' : ''} on {ivrExpirationDate.toLocaleDateString()}.
          </div>
        )}

        {/* Error Message */}
        {error && (
          <div className="alert alert-error" style={{ marginBottom: 'var(--space-lg)' }}>
            {error}
          </div>
        )}

        {/* Checklist Form */}
        <form onSubmit={handleSubmit}>
          {/* Checklist Items */}
          <div className="card" style={{ marginBottom: 'var(--space-xl)' }}>
            <h2 className="card-title">Service Checklist</h2>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-lg)' }}>
              {data.checklist.config.fields?.map(field => (
                <div key={field.id} style={{ padding: 'var(--space-md)', background: 'var(--color-bg-primary)', borderRadius: 'var(--radius-md)' }}>
                  <div style={{ marginBottom: 'var(--space-sm)', fontWeight: 600 }}>
                    {field.label}
                    {field.required && <span style={{ color: 'var(--color-error)', marginLeft: '4px' }}>*</span>}
                  </div>
                  <div style={{ display: 'flex', gap: 'var(--space-md)', flexWrap: 'wrap' }}>
                    <label style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-xs)', cursor: 'pointer' }}>
                      <input
                        type="radio"
                        name={field.id}
                        value="complete"
                        checked={formData[field.id] === 'complete'}
                        onChange={() => handleRadioChange(field.id, 'complete')}
                        disabled={submitting}
                        style={{ cursor: 'pointer' }}
                      />
                      <span style={{ color: 'var(--color-success)' }}>✓ Complete</span>
                    </label>
                    <label style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-xs)', cursor: 'pointer' }}>
                      <input
                        type="radio"
                        name={field.id}
                        value="incomplete"
                        checked={formData[field.id] === 'incomplete'}
                        onChange={() => handleRadioChange(field.id, 'incomplete')}
                        disabled={submitting}
                        style={{ cursor: 'pointer' }}
                      />
                      <span style={{ color: 'var(--color-error)' }}>✗ Incomplete</span>
                    </label>
                    <label style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-xs)', cursor: 'pointer' }}>
                      <input
                        type="radio"
                        name={field.id}
                        value="na"
                        checked={formData[field.id] === 'na'}
                        onChange={() => handleRadioChange(field.id, 'na')}
                        disabled={submitting}
                        style={{ cursor: 'pointer' }}
                      />
                      <span style={{ color: 'var(--color-text-tertiary)' }}>N/A</span>
                    </label>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Photo Upload */}
          <div className="card" style={{ marginBottom: 'var(--space-xl)' }}>
            <h2 className="card-title">Photo Documentation (Minimum 3 Required)</h2>

            <input
              type="file"
              id="photo-upload"
              accept="image/*"
              multiple
              onChange={handlePhotoUpload}
              style={{ display: 'none' }}
              disabled={submitting}
            />

            <label htmlFor="photo-upload" className="photo-upload-zone">
              <div style={{ fontSize: '3rem', marginBottom: 'var(--space-md)' }}>📸</div>
              <div style={{ fontSize: '1.125rem', fontWeight: 500, marginBottom: 'var(--space-sm)' }}>
                Click to Upload Photos
              </div>
              <div className="text-secondary text-sm">
                or drag and drop images here
              </div>
              <div className="text-tertiary text-xs" style={{ marginTop: 'var(--space-sm)' }}>
                {photos.length} photo{photos.length !== 1 ? 's' : ''} uploaded
              </div>
            </label>

            {/* Photo Previews */}
            {photos.length > 0 && (
              <div className="photo-preview-grid">
                {photos.map(photo => (
                  <div key={photo.id} className="photo-preview">
                    <img src={photo.preview} alt="Preview" />
                    <button
                      type="button"
                      className="photo-preview-remove"
                      onClick={() => removePhoto(photo.id)}
                      disabled={submitting}
                      aria-label="Remove photo"
                    >
                      ×
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Notes */}
          <div className="card" style={{ marginBottom: 'var(--space-xl)' }}>
            <h2 className="card-title">Additional Notes</h2>
            <textarea
              className="form-textarea"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Add any additional notes, observations, or issues encountered during service..."
              rows={5}
              disabled={submitting}
            />
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            className="btn btn-primary btn-full btn-lg"
            disabled={submitting || isExpired}
          >
            {submitting ? (
              <>
                <span className="spinner" />
                Submitting...
              </>
            ) : (
              'Submit Checklist'
            )}
          </button>
        </form>
      </div>
    </div>
  );
}
