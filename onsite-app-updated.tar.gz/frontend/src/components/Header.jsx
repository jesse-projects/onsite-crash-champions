import React from 'react';
import { Link } from 'react-router-dom';
import { useTheme } from '../context/ThemeContext';
import { authAPI } from '../utils/api';

export default function Header({ showLogout = false }) {
  const { theme, toggleTheme } = useTheme();

  const handleLogout = () => {
    authAPI.logout();
    window.location.href = '/login';
  };

  return (
    <header style={{
      background: 'var(--color-bg-elevated)',
      borderBottom: '2px solid var(--color-border)',
      padding: 'var(--space-lg) 0',
      position: 'sticky',
      top: 0,
      zIndex: 100,
      boxShadow: 'var(--shadow-md)'
    }}>
      <div className="container" style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between'
      }}>
        {/* Logo */}
        <Link to="/" style={{
          fontSize: '1.5rem',
          fontWeight: 700,
          color: 'var(--color-text-primary)',
          textDecoration: 'none',
          letterSpacing: '-0.02em'
        }}>
          <span style={{ color: 'var(--color-accent-primary)' }}>OnSite</span>
          <span style={{
            fontSize: '0.75rem',
            fontFamily: 'var(--font-mono)',
            marginLeft: 'var(--space-sm)',
            color: 'var(--color-text-tertiary)',
            verticalAlign: 'middle'
          }}>v1.0</span>
        </Link>

        {/* Actions */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-md)' }}>
          {/* Navigation (when logged in) */}
          {showLogout && (
            <nav style={{ display: 'flex', gap: 'var(--space-sm)', marginRight: 'var(--space-md)' }}>
              <Link to="/dashboard" className="btn-ghost btn-sm">
                Dashboard
              </Link>
              <Link to="/subcontractors" className="btn-ghost btn-sm">
                Vendors
              </Link>
              <Link to="/debug" className="btn-ghost btn-sm">
                Debug
              </Link>
            </nav>
          )}

          {/* Theme Toggle */}
          <button
            onClick={toggleTheme}
            className="btn-ghost btn-sm"
            aria-label="Toggle theme"
            style={{
              fontSize: '1.25rem',
              padding: '0.5rem'
            }}
          >
            {theme === 'light' ? '🌙' : '☀️'}
          </button>

          {/* Logout Button */}
          {showLogout && (
            <button
              onClick={handleLogout}
              className="btn-secondary btn-sm"
            >
              Logout
            </button>
          )}
        </div>
      </div>
    </header>
  );
}
